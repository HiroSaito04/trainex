
import {
  sendTrainexInput,
} from "./trainexClient.js";

// Single input entry for the website.
export function sendInput(event) {
  return sendTrainexInput(event);
}

// Preserve common adapter function names.
export const dispatchInput = sendInput;
export const dispatchTrainexInput = sendInput;
