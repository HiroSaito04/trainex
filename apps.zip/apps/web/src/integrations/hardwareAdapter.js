
import {
  forwardHardwareInput,
} from "./inputAdapter.js";

let socket = null;

let hardware = Object.freeze({
  status: "disconnected",
  deviceId: null,
  error: null,
  method: null,
  lastMessage: null,
});

let sequence = -1;

const listeners = new Set();

export const getHardwareSnapshot = () => hardware;

export const subscribeHardware = (callback) => {
  listeners.add(callback);

  return () => listeners.delete(callback);
};

function update(patch) {
  hardware = Object.freeze({
    ...hardware,
    ...patch,
  });

  listeners.forEach((notify) => notify());
}

export function disconnectHardware() {
  const previous = socket;

  socket = null;

  previous?.close();

  sequence = -1;

  update({
    status: "disconnected",
    deviceId: null,
    method: null,
    error: null,
  });
}

// Requires a separately deployed relay with
// pair / paired / input message support.
// Server must authenticate session pairing.

export function connectHardware({
  endpoint,
  sessionId,
  pairingCode,
}) {
  if (!endpoint?.startsWith("wss://")) {
    throw new Error(
      "A secure wss:// relay endpoint is required."
    );
  }

  if (!sessionId?.trim() || !pairingCode?.trim()) {
    throw new Error(
      "Session ID and pairing code are required."
    );
  }

  disconnectHardware();

  const ws = new WebSocket(endpoint);

  socket = ws;

  update({
    status: "connecting",
    method: "websocket",
    error: null,
  });

  ws.onopen = () => {
    if (socket !== ws) return;

    // Socket opening does not prove pairing.
    ws.send(
      JSON.stringify({
        type: "pair",
        protocolVersion: 1,
        role: "web",
        sessionId: sessionId.trim(),
        pairingCode: pairingCode.trim(),
      })
    );
  };

  ws.onmessage = (event) => {
    if (socket !== ws) return;

    let message;

    try {
      message = JSON.parse(event.data);
    } catch {
      update({
        error: "Received malformed relay data.",
      });
      return;
    }

    if (
      message.type === "paired" &&
      message.sessionId === sessionId.trim()
    ) {
      sequence = -1;

      update({
        status: "connected",
        deviceId: message.deviceId ?? null,
        error: null,
      });

      return;
    }

    if (message.type === "pair-error") {
      update({
        status: "error",
        error:
          message.message || "Pairing rejected.",
      });

      ws.close();
      return;
    }

    if (
      message.type === "input" &&
      hardware.status === "connected"
    ) {
      if (message.sessionId !== sessionId.trim()) {
        return;
      }

      if (
        !Number.isSafeInteger(message.sequence) ||
        message.sequence <= sequence
      ) {
        return;
      }

      sequence = message.sequence;

      update({
        lastMessage: message.control,
      });

      try {
        Promise.resolve(
          forwardHardwareInput(message)
        ).catch((error) => {
          update({ error: error.message });
        });
      } catch (error) {
        update({ error: error.message });
      }
    }
  };

  ws.onerror = () => {
    if (socket === ws) {
      update({
        status: "error",
        error: "Relay connection failed.",
      });
    }
  };

  ws.onclose = () => {
    if (socket !== ws) return;

    socket = null;

    update({
      status: "disconnected",
      deviceId: null,
    });
  };
}
