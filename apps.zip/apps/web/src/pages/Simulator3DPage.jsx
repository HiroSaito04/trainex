
import PageHeader from "../components/common/PageHeader.jsx";

import SimulatorContainer from "../components/simulation/SimulatorContainer.jsx";

import SessionToolbar from "../components/simulation/SessionToolbar.jsx";

import SimulationStatus from "../components/simulation/SimulationStatus.jsx";

export default function Simulator3DPage() {
  return (
    <div className="container page">
      <PageHeader
        eyebrow="SIMULATION / 3D"
        title="3D Driver Cabin"
        description="The 3D visualization will load optimized GLB assets and operate the same active train state."
      />

      <SessionToolbar />

      <div className="simulator-grid">
        <SimulatorContainer mode="3d" />

        <SimulationStatus />
      </div>
    </div>
  );
}
