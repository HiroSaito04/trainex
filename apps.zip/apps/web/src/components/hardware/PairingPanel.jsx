
import { useState } from "react";

import {
  connectHardware,
  disconnectHardware,
} from "../../integrations/hardwareAdapter.js";

import {
  useHardwareStatus,
} from "../../context/useHardwareStatus.js";

export default function PairingPanel() {
  const { status } = useHardwareStatus();

  const [endpoint, setEndpoint] = useState(
    import.meta.env.VITE_TRAINEX_RELAY_URL ?? ""
  );

  const [sessionId, setSessionId] =
    useState("");

  const [pairingCode, setPairingCode] =
    useState("");

  const [error, setError] =
    useState("");

  function connect(event) {
    event.preventDefault();

    try {
      setError("");

      connectHardware({
        endpoint,
        sessionId,
        pairingCode,
      });

      setPairingCode("");
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <section className="panel card-stack">
      <div className="section-heading">
        <p className="eyebrow">
          OPTIONAL HARDWARE
        </p>

        <h2>
          Connect an ESP32 console
        </h2>
      </div>

      <p>
        Connect through an approved secure relay.
        Your relay server must implement authenticated
        device/session pairing. Direct mobile
        USB Serial is not assumed.
      </p>

      <form
        className="form-stack"
        onSubmit={connect}
      >
        <label>
          Secure WebSocket endpoint

          <input
            type="url"
            placeholder="wss://relay.example.com"
            value={endpoint}
            onChange={(e) =>
              setEndpoint(e.target.value)
            }
            required
          />
        </label>

        <label>
          Simulation session ID

          <input
            value={sessionId}
            onChange={(e) =>
              setSessionId(e.target.value)
            }
            placeholder="Session identifier"
            autoComplete="off"
            required
          />
        </label>

        <label>
          Pairing code

          <input
            type="password"
            value={pairingCode}
            onChange={(e) =>
              setPairingCode(e.target.value)
            }
            placeholder="One-time pairing code"
            autoComplete="off"
            required
          />
        </label>

        <div className="action-row">
          <button
            className="btn btn-primary"
            type="submit"
            disabled={
              status === "connecting" ||
              status === "connected"
            }
          >
            Connect
          </button>

          <button
            className="btn btn-secondary"
            type="button"
            onClick={disconnectHardware}
            disabled={status === "disconnected"}
          >
            Disconnect
          </button>
        </div>

        {error && (
          <p
            className="feedback-error"
            role="alert"
          >
            {error}
          </p>
        )}
      </form>

      <p className="tiny-note">
        The relay and ESP32 firmware are separate
        modules and must match the eventual
        communication protocol.
      </p>
    </section>
  );
}
