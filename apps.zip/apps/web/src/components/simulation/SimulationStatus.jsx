
import {
  useTrainState,
} from "../../context/useTrainState.js";

export default function SimulationStatus() {
  const {
    ready,
    trainState,
    sessionStatus,
  } = useTrainState();

  const display =
    trainState?.display ?? trainState ?? {};

  return (
    <aside
      className="panel status-panel"
      aria-live="polite"
    >
      <div className="section-heading">
        <p className="eyebrow">
          LIVE MONITOR
        </p>

        <h2>Train Status</h2>
      </div>

      {!ready && (
        <p className="notice">
          The simulation engine has not been
          connected. Values are unavailable.
        </p>
      )}

      <div className="metric-grid">
        <div className="metric">
          <span>Speed</span>
          <strong>
            {ready && Number.isFinite(display.speed)
              ? `${display.speed.toFixed(1)} km/h`
              : "—"}
          </strong>
        </div>

        <div className="metric">
          <span>Master Handle</span>
          <strong>
            {ready
              ? String(display.masterHandle ?? "—")
              : "—"}
          </strong>
        </div>

        <div className="metric">
          <span>Passenger Doors</span>
          <strong>
            {ready
              ? String(
                  display.doors ??
                  display.doorState ??
                  "—"
                )
              : "—"}
          </strong>
        </div>

        <div className="metric">
          <span>All Doors Closed</span>
          <strong>
            {ready &&
            typeof display.allDoorsClosed === "boolean"
              ? display.allDoorsClosed ? "Yes" : "No"
              : "—"}
          </strong>
        </div>

        <div className="metric">
          <span>Emergency Brake</span>
          <strong>
            {ready &&
            typeof display.emergencyBrake === "boolean"
              ? display.emergencyBrake
                ? "Active"
                : "Clear"
              : "—"}
          </strong>
        </div>

        <div className="metric">
          <span>Session</span>
          <strong>
            {ready
              ? sessionStatus
              : "Unavailable"}
          </strong>
        </div>
      </div>
    </aside>
  );
}
