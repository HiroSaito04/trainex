
import { useState } from "react";

import Button from "../common/Button.jsx";

import {
  useTrainState,
} from "../../context/useTrainState.js";

import {
  sessionCoordinator,
} from "../../services/sessionCoordinator.js";

import {
  audioService,
} from "../../services/audioService.js";

export default function SessionToolbar() {
  const {
    ready,
    sessionStatus,
  } = useTrainState();

  const [error, setError] = useState("");

  const [audio, setAudio] = useState(
    audioService.isEnabled()
  );

  const running = sessionStatus === "running";
  const paused = sessionStatus === "paused";

  async function act(fn) {
    try {
      setError("");
      await fn();
    } catch (e) {
      setError(e.message);
    }
  }

  async function toggleAudio() {
    try {
      if (audio) {
        audioService.mute();
        setAudio(false);
      } else {
        await audioService.enable();
        setAudio(true);
        await audioService.playTestTone();
      }
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div className="panel toolbar">
      <div className="toolbar-actions">
        <Button
          onClick={() =>
            act(sessionCoordinator.start)
          }
          disabled={
            !ready || running || paused
          }
        >
          Start
        </Button>

        <Button
          variant="secondary"
          onClick={() =>
            act(
              running
                ? sessionCoordinator.pause
                : sessionCoordinator.resume
            )
          }
          disabled={
            !ready || (!running && !paused)
          }
        >
          {running ? "Pause" : "Resume"}
        </Button>

        <Button
          variant="ghost"
          onClick={() =>
            act(sessionCoordinator.reset)
          }
          disabled={!ready}
        >
          Reset
        </Button>

        <Button
          variant="ghost"
          onClick={() =>
            act(sessionCoordinator.end)
          }
          disabled={!ready}
        >
          End
        </Button>

        <Button
          variant="secondary"
          onClick={toggleAudio}
        >
          {audio
            ? "Mute Audio"
            : "Enable Audio"}
        </Button>
      </div>

      {error && (
        <p
          className="feedback-error"
          role="alert"
        >
          {error}
        </p>
      )}
    </div>
  );
}
