
import {
  trainexClient,
} from "../integrations/trainexClient.js";

// Website-only session orchestration.
// Actual session states belong to the engine.

export const sessionCoordinator = {
  start: () =>
    trainexClient.startSession(),

  pause: () =>
    trainexClient.pauseSession(),

  resume: () =>
    trainexClient.resumeSession(),

  reset: () =>
    trainexClient.resetSession(),

  end: () =>
    trainexClient.endSession(),
};
